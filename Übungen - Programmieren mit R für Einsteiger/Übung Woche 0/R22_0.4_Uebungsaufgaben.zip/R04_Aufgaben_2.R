codeoceanR::rt_score()
# Siehe Anleitung im Kursvideo / PDF Abschnitt 1.4 Übungsaufgaben

# A3 ----
# Teile 294 durch 7.
294/7


# A4 ----
# Multipliziere 12 mit 3,5.
# Tipp: Dezimalzahlen werden beim Programmieren nicht mit einem Komma dargestellt.
12*3.5


# Wenn du fertig bist, übermittle bitte deinen Score an openHPI.
# Im Browser: klicke nach einem Bewerten rechts auf "Code zur Bewertung abgeben"
# In Rstudio: führe folgendes aus:
# codeoceanR::rt_submit()