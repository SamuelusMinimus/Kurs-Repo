# A1 ----
# Subtrahiere 7 von 49. Es reicht, einfach den Code dafür zu schreiben.
49-7


# In der Browser-Instanz von CodeOcean: drücke ALT + R (oder klicke auf 'Ausführen').
# In Rstudio: mit dem Kursor auf der Lösungszeile, drücke STRG + Enter (oder klicke rechts oben 'Run').


# Wenn das Ergebnis richtig erscheint, lass es überprüfen:
# Im Browser: drücke ALT + S (oder klicke auf 'Bewerten').
# In Rstudio: Führe die nächste Zeile aus (oder klicke auf 'Source').
codeoceanR::rt_score()
# Ignoriere Meldungen zu Aufgaben, an denen du noch nicht gearbeitet hast 
# (sie zeigen an, wie viel Arbeit noch übrig ist).


# A2 ----
# Multipliziere 21 mit 2.
21*2


# Score auch jetzt wieder, um deine Lösung prüfen zu lassen.
# Es lohnt sich, das mindestens nach jeder Aufgabe einmal zu machen.

# In Rstudio: CTRL + SHIFT + S um ohne Mausklickerei 'source' aufzurufen.
# Das führt das ganze Sckript inklusive rt_score() aus.

# Führe Code oft aus und lasse oft bewerten, um Fehler leicht zu finden.

# Mache weiter in "R04_Aufgaben_2.R"