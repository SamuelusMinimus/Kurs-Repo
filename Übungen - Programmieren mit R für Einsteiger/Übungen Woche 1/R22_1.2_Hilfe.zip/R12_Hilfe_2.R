codeoceanR::rt_score()

# A6 ----
# Wieviele Seiten hat das RefCard von Tom Short?
refCardAnzahlSeiten <- 4


# A7 ----
# Im Rstudio base R cheat sheet steht die Syntax, um die Doku von Funktionen aufzurufen.
# (Gleich im Abschnitt Getting Help)
# Welche Funktion wird dort als erstes Beispiel verwendet?
cheatSheetFunktion <- "mean"


# Pro Tipp: drucke eine RefCard deiner Wahl aus und markiere 
# nach und nach farblich, was du alles gelernt und verstanden hast.


# A8 ----
# Was ist der Link zu aktuellen R Fragen auf Stackoverflow? (der https Teil ist optional)
soLinkR <- "URL_hier"


# A9 ----
# Welchen Beitrag im Kursforum findest du bisher am hilfreichsten?
forumLink <- "URL_hier"


# Wenn du fertig bist, übermittle bitte deinen Punktestand an openHPI mit:
# codeoceanR::rt_submit()