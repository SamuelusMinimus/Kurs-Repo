codeoceanR::rt_score()

# Dies ist eine bewertete Aufgabe für ein Zertifikat. 
# Sie muss vor der angegebenen Zeit eingereicht werden (mit rt_submit()).
# Besprich vor der Abgabefrist bitte keine Lösungen im Forum, erst danach.


# A1 ----
# Im RefCard von Tom Short wird unter Data creation Operatorpräzedenz angesprochen.
# Welcher Operator wird dort mit Priorität vor dem + Operator gelistet?
# Hinweis: Zum Begriff Operator siehe auch ?Syntax
operatorVorPlus <- ":" 
# Tipp: Doppelklick um ganzes Wort zu markieren (und dann zu ersetzen)


# A2 ----
# Im Base R RefCard von Rstudio wird neben `sort` eine Funktion vorgestellt,
# die den Inhalt eines Vektors in umgekehrter Reihenfolge ausgibt.
# Wie heißt diese Funktion? (Sie ist nicht in den Kursfolien enthalten)
umkehrFunktion <- "rev()"


# A3 ----
# Welche Funktion zeigt zusammenfassend die Struktur eines Objektes?
strukturFunktion <- "str()"

# Mache weiter in "R19_Grundlagen_2.R"
